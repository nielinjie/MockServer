## Mockserver for RAML
A simple mockserver for RAML.

Using [WireMock](http://wiremock.org/) and [RAML java parser](https://github.com/raml-org/raml-java-parser) 
until the [new Java RAML parser](https://github.com/raml-org/raml-java-parser-2) is ready.

